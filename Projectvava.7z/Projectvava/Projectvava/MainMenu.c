#include "Declarations.h"

void ExitProgram();

void ExitProgram()
{
	set_cursor_visible(1);
	clrScr();
	exit(1);
}

