#ifndef __PARTS_H__
#define __PARTS_H__


#define TOP_BOT 205
#define TOP_RIGHT 187
#define TOP_LEFT 201
#define BOT_RIGHT 188
#define BOT_left 200
#define LEFT_RIGHT 186
#define RECTANGLE 219
#define FOREGROUND_WHITE 0x0007
#define BS 8

#endif __PARTS_H__