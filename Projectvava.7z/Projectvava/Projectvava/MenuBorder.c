#include "Declarations.h"


void menu() {
	int row = 5, col = 10;
	char temp = TOP_BOT;

	

	for (row = 1, col = 4; col < 75; col++) {
		mainchInfo[row * coord.X + col].Char.AsciiChar = temp;
		mainchInfo[row * coord.X + col].Attributes = FOREGROUND_GREEN | FOREGROUND_INTENSITY;

		put_screen(&coord, mainchInfo);
	}
	temp = TOP_LEFT;
	row = 1; col = 4;
	mainchInfo[row * coord.X + col].Char.AsciiChar = temp;
	mainchInfo[row * coord.X + col].Attributes = FOREGROUND_GREEN | FOREGROUND_INTENSITY;

	put_screen(&coord, mainchInfo);

	temp = LEFT_RIGHT;
	for (row = 2, col = 4; row < 24; row++) {
		mainchInfo[row * coord.X + col].Char.AsciiChar = temp;
		mainchInfo[row * coord.X + col].Attributes = FOREGROUND_GREEN | FOREGROUND_INTENSITY;

		put_screen(&coord, mainchInfo);
	}
	temp = BOT_left;
	row = 24; col = 4;
	mainchInfo[row * coord.X + col].Char.AsciiChar = temp;
	mainchInfo[row * coord.X + col].Attributes = FOREGROUND_GREEN | FOREGROUND_INTENSITY;

	put_screen(&coord, mainchInfo);

	temp = TOP_BOT;
	for (row = 24, col = 5; col < 75; col++) {
		mainchInfo[row * coord.X + col].Char.AsciiChar = temp;
		mainchInfo[row * coord.X + col].Attributes = FOREGROUND_GREEN | FOREGROUND_INTENSITY;

		put_screen(&coord, mainchInfo);
	}
	temp = BOT_RIGHT;
	row = 24; col = 75;
	mainchInfo[row * coord.X + col].Char.AsciiChar = temp;
	mainchInfo[row * coord.X + col].Attributes = FOREGROUND_GREEN | FOREGROUND_INTENSITY;

	put_screen(&coord, mainchInfo);
	temp = TOP_RIGHT;
	row = 1; col = 75;
	mainchInfo[row * coord.X + col].Char.AsciiChar = temp;
	mainchInfo[row * coord.X + col].Attributes = FOREGROUND_GREEN | FOREGROUND_INTENSITY;

	put_screen(&coord, mainchInfo);
	temp = LEFT_RIGHT;
	for (row = 2, col = 75; row < 24; row++) {
		mainchInfo[row * coord.X + col].Char.AsciiChar = temp;
		mainchInfo[row * coord.X + col].Attributes = FOREGROUND_GREEN | FOREGROUND_INTENSITY;

		put_screen(&coord, mainchInfo);
	}

}
