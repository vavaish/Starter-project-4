#include "declarations.h"

void Name(char string[256]) {
	int counter=0;
	
	int get;
	
	printf("FIrst name | Last name:  ");
	while (1)
	{

		get = _getch();
		if ((get >= 'a'&&get <= 'z') || (get >= 'A'&&get <= 'Z'))
		{
			string[counter] = get;
			counter++;
			string[counter] = '\0';
			_putch(get);
		}

		if ((get == BS) && (counter > 0))
		{
			_putch('\b');
			_putch(' ');
			_putch('\b');
			string[counter] = ' ';
			counter--;

		}
		if (get == '\r')
		{
			
			break;
			
			
		}
		
	}

}
