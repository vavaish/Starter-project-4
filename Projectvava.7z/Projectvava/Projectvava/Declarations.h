#ifndef __DECLARTIONS_H__
#define __DECLARTIONS_H__

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <windows.h>
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <direct.h>
#include <time.h>
//enum Alignment_ {alLeft, alCenter, alRight} Alignment;
extern int GetKey();

#define MAX 255

#include "keys.h"
//#include "uObjects.h"
#include "Globals.h"
#include "cons.h"
#include "Parts.h"
//#include "Colors.h"
//#include "uFunctions.h"
#endif /* __DECLARTIONS_H__ */
