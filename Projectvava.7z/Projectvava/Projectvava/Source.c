#include "Declarations.h"

void menu();
void InitProgram(int argc, char *argv[]);
int GetKey();
void Gotoxy(int x, int y);
void MenuSelect(int *ch,int *y,int *row);
void Name(char string[256]);
int main(int argc, char *argv[])
{
	system("COLOR 0A");
	int x = 28;
	int y = 3;
	
	int ch;
	int row;
	int Larger = 0;
	int getch();
	char stringer[256];

	InitProgram(argc, argv);
	menu();

	
	while(1)
	{

		


		MenuSelect(&ch, &y, &row);
		Gotoxy(x, y);
		if ((y == 3) && (ch == '\r'))
		{
			Name(stringer);


		}
		if ((y == 8) && (ch == '\r'))
		{
			y = 3;
			row = 3;
			printf("%s",stringer);
		}
		if (ch == 27) 
		{

			break;
		}
	}

	system("pause");
	GetKey();
	clrScr();
	
	return 1;
}

int GetKey()
{
	int getch();
	int ch;
	ch = getch();
	if (ch == 0 || ch == 224) {
		ch = getch();
		ch += 256;
	}
	return ch;
}

void InitProgram(int argc, char *argv[])
{

	mainchInfo = get_screen(&coord);

	init_console(KBValue);
}
void Gotoxy(int x, int y)

{

	COORD scrn;

	HANDLE hOuput = GetStdHandle(STD_OUTPUT_HANDLE);

	scrn.X = x; scrn.Y = y;

	SetConsoleCursorPosition(hOuput, scrn);

}
